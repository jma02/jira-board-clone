import JiraBoard from '@/components/JiraBoard';

export default function Home() {
  return <JiraBoard />;
}
